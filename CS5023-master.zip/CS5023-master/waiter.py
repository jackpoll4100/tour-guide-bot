import time
if __name__ == '__main__':
	time.sleep(10)
	print("waiter finishes")
